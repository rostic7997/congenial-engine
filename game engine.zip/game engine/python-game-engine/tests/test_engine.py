import unittest
from src.engine.core import GameEngine

class TestGameEngine(unittest.TestCase):

    def setUp(self):
        self.engine = GameEngine()

    def test_initialization(self):
        self.assertIsNotNone(self.engine)

    def test_game_loop(self):
        self.engine.start()
        self.assertTrue(self.engine.is_running)

    def test_update(self):
        initial_state = self.engine.state
        self.engine.update()
        self.assertNotEqual(initial_state, self.engine.state)

    def test_render(self):
        self.engine.start()
        self.engine.render()
        self.assertTrue(self.engine.has_rendered)

if __name__ == '__main__':
    unittest.main()