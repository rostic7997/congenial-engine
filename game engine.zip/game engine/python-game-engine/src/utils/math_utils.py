# math_utils.py

import math

def vector_add(v1, v2):
    """Сложение двух векторов."""
    return [v1[0] + v2[0], v1[1] + v2[1], v1[2] + v2[2]]

def vector_subtract(v1, v2):
    """Вычитание двух векторов."""
    return [v1[0] - v2[0], v1[1] - v2[1], v1[2] - v2[2]]

def vector_dot(v1, v2):
    """Скалярное произведение двух векторов."""
    return v1[0] * v2[0] + v1[1] * v2[1] + v1[2] * v2[2]

def vector_magnitude(v):
    """Вычисление длины вектора."""
    return math.sqrt(v[0]**2 + v[1]**2 + v[2]**2)

def normalize(v):
    """Нормализация вектора."""
    mag = vector_magnitude(v)
    if mag == 0:
        return [0, 0, 0]
    return [v[0] / mag, v[1] / mag, v[2] / mag]

def matrix_multiply(m1, m2):
    """Умножение двух матриц."""
    return [[sum(a * b for a, b in zip(m1_row, m2_col)) for m2_col in zip(*m2)] for m1_row in m1]