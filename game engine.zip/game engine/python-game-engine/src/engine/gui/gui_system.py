class GuiSystem:
    def __init__(self):
        self.elements = []

    def add_element(self, element):
        self.elements.append(element)

    def remove_element(self, element):
        if element in self.elements:
            self.elements.remove(element)

    def update(self):
        for element in self.elements:
            element.update()

    def render(self, surface):
        for element in self.elements:
            element.render(surface)