class Renderer2D:
    def __init__(self):
        pass

    def draw_rectangle(self, x, y, width, height, color):
        # Код для рисования прямоугольника
        pass

    def draw_circle(self, x, y, radius, color):
        # Код для рисования круга
        pass

    def draw_image(self, image, x, y):
        # Код для отображения изображения
        pass

    def clear(self):
        # Код для очистки экрана
        pass