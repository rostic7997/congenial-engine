# main.py

from engine.core import GameEngine

def main():
    game = GameEngine()
    game.run()

if __name__ == "__main__":
    main()